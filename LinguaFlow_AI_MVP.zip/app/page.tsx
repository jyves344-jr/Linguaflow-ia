 "use client";
import { useState } from "react";
import { ArrowRight, Brain, Check, Globe2, MessageCircle, Play, Sparkles, Trophy, Zap } from "lucide-react";

const languages = [
  {name:"English", flag:"🇬🇧", level:"A1 → C1"},
  {name:"Spanish", flag:"🇪🇸", level:"A1 → C1"},
  {name:"French", flag:"🇫🇷", level:"A1 → C1"}
];

export default function Home(){
  const [lang,setLang]=useState("English");
  const [level,setLevel]=useState("A1");
  const [tab,setTab]=useState<"home"|"dashboard">("home");
  const [chat,setChat]=useState("");
  const [messages,setMessages]=useState<string[]>([]);
  const send=()=>{ if(!chat.trim()) return; setMessages([...messages,chat.trim()]); setChat(""); };

  if(tab==="dashboard") return <Dashboard lang={lang} level={level} onBack={()=>setTab("home")} />;
  return <main>
    <nav className="nav">
      <div className="brand"><span className="logo">L</span> LinguaFlow <b>AI</b></div>
      <div className="navlinks"><a href="#features">Features</a><a href="#pricing">Pricing</a><button className="ghost" onClick={()=>setTab("dashboard")}>Open dashboard</button></div>
    </nav>

    <section className="hero">
      <div className="heroCopy">
        <div className="pill"><Sparkles size={15}/> Your personal AI language teacher</div>
        <h1>Learn a language.<br/><span>Every day. With AI.</span></h1>
        <p>Short lessons, smart practice and an AI tutor that adapts to your level. Build a real-world language habit in just 10 minutes a day.</p>
        <div className="actions"><button className="primary" onClick={()=>setTab("dashboard")}>Start learning free <ArrowRight size={18}/></button><button className="secondary"><Play size={17}/> See how it works</button></div>
        <div className="trust"><span>✓ No credit card</span><span>✓ A1–C1 courses</span><span>✓ Learn on mobile</span></div>
      </div>
      <div className="heroCard">
        <div className="cardTop"><span>Today’s lesson</span><span className="streak">🔥 7 day streak</span></div>
        <h3>Introducing yourself</h3><p>English · A1 · 10 min</p>
        <div className="progress"><i></i></div>
        <div className="miniRow"><div className="avatar">AI</div><div><b>Your AI Tutor</b><small>Ready to practice with you</small></div><MessageCircle size={20}/></div>
        <button className="wide" onClick={()=>setTab("dashboard")}>Continue lesson <ArrowRight size={17}/></button>
      </div>
    </section>

    <section className="section" id="features">
      <div className="center"><div className="eyebrow">WHY LINGUAFLOW</div><h2>Everything you need to actually improve</h2><p>Designed around consistency, practice and useful conversations—not endless theory.</p></div>
      <div className="features">
        {[
          [Brain,"AI Tutor","Practice conversations and get instant explanations."],
          [Zap,"10-minute lessons","Small daily sessions designed to keep you consistent."],
          [Trophy,"Progress system","Streaks, XP and milestones make progress visible."],
          [Globe2,"3 languages","Start with English, Spanish or French and expand later."]
        ].map(([Icon,title,desc]:any)=><div className="feature" key={title}><Icon size={25}/><h3>{title}</h3><p>{desc}</p></div>)}
      </div>
    </section>

    <section className="section chooser">
      <div><div className="eyebrow">START NOW</div><h2>Choose your learning path</h2><p>Pick a language and level. You can change it anytime.</p></div>
      <div className="choices"><div className="langGrid">{languages.map(l=><button className={"lang "+(lang===l.name?"selected":"")} onClick={()=>setLang(l.name)} key={l.name}><span>{l.flag}</span><b>{l.name}</b><small>{l.level}</small></button>)}</div>
      <div className="levels">{["A1","A2","B1","B2","C1"].map(l=><button className={level===l?"active":""} onClick={()=>setLevel(l)} key={l}>{l}</button>)}</div>
      <button className="primary" onClick={()=>setTab("dashboard")}>Start {lang} {level} <ArrowRight size={18}/></button></div>
    </section>

    <section className="section pricing" id="pricing"><div className="center"><div className="eyebrow">SIMPLE PRICING</div><h2>Start free. Upgrade when ready.</h2></div>
      <div className="plans">{[
        ["Free","$0","Basic lessons","5 lessons / week","Progress tracking"],
        ["Pro","$10","Everything in Free","Unlimited lessons","AI Tutor","Speaking practice"],
        ["Premium AI","$15","Everything in Pro","Advanced AI practice","Priority features","Certificates"]
      ].map((p:any[],i)=><div className={"plan "+(i===1?"featured":"")} key={p[0]}>{i===1&&<div className="best">MOST POPULAR</div>}<h3>{p[0]}</h3><div className="price">{p[1]}<small>/month</small></div>{p.slice(2).map(x=><div className="check" key={x}><Check size={16}/>{x}</div>)}<button className={i===1?"primary":"secondary"} onClick={()=>setTab("dashboard")}>Choose plan</button></div>)}</div>
    </section>

    <section className="cta"><h2>Your next language starts today.</h2><p>Build the habit first. The fluency follows.</p><button className="primary" onClick={()=>setTab("dashboard")}>Create my free account <ArrowRight size={18}/></button></section>
    <footer>© 2026 LinguaFlow AI · Built for learners everywhere</footer>
  </main>
}

function Dashboard({lang,level,onBack}:{lang:string,level:string,onBack:()=>void}){
 return <main className="dash"><nav className="nav"><div className="brand"><span className="logo">L</span> LinguaFlow <b>AI</b></div><button className="ghost" onClick={onBack}>← Home</button></nav>
 <div className="dashHead"><div><div className="eyebrow">STUDENT DASHBOARD</div><h1>Welcome back 👋</h1><p>Today: {lang} · {level}</p></div><div className="streakBox">🔥 <b>7</b><small>day streak</small></div></div>
 <div className="dashGrid"><div className="mainPanel"><div className="panelTitle"><div><span className="tag">TODAY’S LESSON</span><h2>Introducing yourself</h2><p>Learn the phrases you need to introduce yourself naturally.</p></div><span className="duration">10 min</span></div><div className="lessonBox"><h3>Quick practice</h3><p>Choose the best response:</p><div className="question">“Nice to meet you!”</div>{["Nice to meet you too!","I am twenty years old.","See you yesterday."].map((x,i)=><button className="answer" key={x}>{String.fromCharCode(65+i)}. {x}</button>)}</div><button className="primary wide">Continue lesson <ArrowRight size={18}/></button></div>
 <aside><div className="sideCard"><div className="sideIcon"><MessageCircle/></div><h3>Talk to your AI Tutor</h3><p>Practice a real conversation and get corrections.</p><div className="chat"><div className="aiMsg">Hi! Let’s practice introducing yourself. 👋</div>{messages.map(m=><div className="userMsg" key={m}>{m}</div>)}</div><div className="input"><input value={chat} onChange={e=>setChat(e.target.value)} onKeyDown={e=>e.key==="Enter"&&send()} placeholder="Type a message..."/><button onClick={send}><ArrowRight size={17}/></button></div></div><div className="sideCard"><h3>Your progress</h3><div className="stat"><b>34%</b><span>Course completion</span></div><div className="progress big"><i></i></div><div className="stat"><b>420 XP</b><span>This month</span></div></div></aside></div></main>
}