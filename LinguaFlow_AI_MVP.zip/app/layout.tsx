import "./globals.css";
export const metadata = { title:"LinguaFlow AI", description:"Learn languages with your AI teacher." };
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}